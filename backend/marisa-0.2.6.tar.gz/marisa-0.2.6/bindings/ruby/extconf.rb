require "mkmf"

have_library("marisa")

create_makefile("marisa")
